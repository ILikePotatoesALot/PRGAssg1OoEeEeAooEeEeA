﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssgCode
{
    internal class Flight : Airline
    {
        public string FlightNumber { get; set; }
        public string Origin {  get; set; }
        public string Destination { get; set; }
        public DateTime ExpectedTime { get; set; }
        public string Status { get; set; }

        public Flight() { }

        public Flight(string flightNumber, string origin, string destination, DateTime expectedTime, string status)
        {
            FlightNumber = flightNumber;
            Origin = origin;
            Destination = destination;
            ExpectedTime = expectedTime;
            Status = status;
        }
        
        public double CalculateFees()
        {
            double fee = 0;
            if (Destination == "Singapore (SIN)") { fee += 500; }
            if (Origin == "Singapore (SIN)") { fee += 800; }
            /*
            this part in between need the lwtff cfft bullshi so i leave to u :)
            */
            return fee;
        }
        
        public override string ToString()
        {
            return $"Flight Number: {FlightNumber,-10}" +
                $"Origin: {Origin,-10}" +
                $"Destination: {Destination,-10}" +
                $"Expected Time: {ExpectedTime,-10}" +
                $"Status: {Status,-10}";
        }


    }
}
